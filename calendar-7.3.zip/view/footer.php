<!-- w3c vaildator -->

<p>
	<a href="http://jigsaw.w3.org/css-validator/check/referer">
		<img style="border:0;width:88px;height:31px"
			src="//jigsaw.w3.org/css-validator/images/vcss"
			alt="올바른 CSS입니다!" />
	</a>
</p>
<p>
	<a href="http://jigsaw.w3.org/css-validator/check/referer">
		<img style="border:0;width:88px;height:31px"
			src="//jigsaw.w3.org/css-validator/images/vcss-blue"
			alt="올바른 CSS입니다!" />
	</a>
</p>


<!-- 수행시간(Execution time) -->
<?php

  $end = $calFn->getExecutionTime();
  $time = $end - $start;
  echo "\t\t\t<br>";
  echo "\t\t\t<span class=\"time_font\">";
  echo "수행시간(Execution Time):";
  echo $time . "초(Sec)</span>";
  
  echo "\t\t\t<br>";
  echo "\t\t\t<span class=\"time_font\">";
  echo "시작시간(Start Time):";
  echo $start . "초(Sec)</span>";
  echo "\t\t\t<br>";
  echo "\t\t\t<span class=\"time_font\">";
  echo "종료시간(End Time):";
  echo $end . "초(Sec)</span>";
?>
</body>
</html>