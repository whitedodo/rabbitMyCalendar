<?php

/*
	File: Connect.php
	Author: Jaspers
	Created by 2018-07-08
	E mail: rabbit.white@daum.net
	Description:
	2019-11-25 / Jasper / PHP 7.3�������� ����
*/

class Connect{
	
	private $host;
	private $user;
	private $pw;
	private $dbName;
	private $dbPort;
	
	public function __construct($host, $user, $pw, $dbName, $dbPort){
		$this->host = $host;
		$this->user = $user;
		$this->pw = $pw;
		$this->dbName = $dbName;
		$this->dbPort = $dbPort;
	}
	
	public function getHost(){
		return $this->host;	
	}
	
	public function getUser(){
		return $this->user;	
	}
	
	public function getPw(){
		return $this->pw;
	}
	
	public function getDBName(){
		return $this->dbName;
	}	

	public function getPort(){
		return $this->dbPort;
	}	
	
}
?>